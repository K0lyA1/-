alert('test');
let div    = document.querySelector('div');
let button = document.querySelector('button');
button.addEventListener('click', function() {
	fetch('http://localhost:8080/ajax.html').then(
		response => {
			return response.text();
		}
	).then(
		text => {
			div.innerHTML = text;
		}
	);
});